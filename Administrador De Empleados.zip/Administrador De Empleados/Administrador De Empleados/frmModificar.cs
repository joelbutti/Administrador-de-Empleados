﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Administrador_De_Empleados
{
    public partial class frmModificar : Form
    {
        public frmModificar()
        {
            InitializeComponent();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            Empleado nuevo = new Empleado();
            EmpleadoConexion conexion = new EmpleadoConexion();
            nuevo.Nombre = tbNombre.Text;
            nuevo.Edad = int.Parse(tbEdad.Text);
            nuevo.Salario = decimal.Parse(tbSalario.Text);
            nuevo.Casado = cbCasado.Checked;

            conexion.modificar(nuevo);

            Close();
        }
    }
}
