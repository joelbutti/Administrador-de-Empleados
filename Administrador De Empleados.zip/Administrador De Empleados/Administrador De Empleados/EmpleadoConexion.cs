﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Administrador_De_Empleados
{
    class EmpleadoConexion
    {
        public List<Empleado> listarEmpleados()
        {
            List<Empleado> Lista = new List<Empleado>();
            SqlConnection conexion = new SqlConnection();
            SqlCommand comando = new SqlCommand();
            SqlDataReader lector;

            conexion.ConnectionString = "data source = DESKTOP-A3AHOCB; initial catalog=EMPLEADOS_DB; integrated security=sspi";
            comando.CommandType = System.Data.CommandType.Text;
            comando.CommandText = "select * from Empleados";
            comando.Connection = conexion;
            conexion.Open();

            lector = comando.ExecuteReader();

            while (lector.Read())
            {
                Empleado aux = new Empleado();
                aux.Id = lector.GetInt32(0);
                aux.Nombre = lector.GetString(1);
                aux.Dni = lector.GetString(2);
                aux.Edad = lector.GetInt32(3);
                aux.Casado = lector.GetBoolean(4);
                aux.Salario = lector.GetDecimal(5);

                Lista.Add(aux);
            }

            conexion.Close();

            return Lista;
        }

        public void modificar(Empleado nuevo)
        {
            SqlConnection conexion = new SqlConnection("data source = DESKTOP-A3AHOCB; initial catalog=EMPLEADOS_DB; integrated security=sspi");
            SqlCommand comando = new SqlCommand();

            comando.Connection = conexion;
            comando.CommandType = System.Data.CommandType.Text;
            comando.Parameters.AddWithValue("@NombreCompleto", nuevo.Nombre);
            comando.Parameters.AddWithValue("@Edad", nuevo.Edad);
            comando.Parameters.AddWithValue("@Casado", nuevo.Casado);
            comando.Parameters.AddWithValue("@Salario", nuevo.Salario);
            comando.CommandText = "update dbo.Empleados set Edad= @Edad, Casado= @Casado, Salario= @Salario where NombreCompleto = @NombreCompleto";

            conexion.Open();
            comando.ExecuteNonQuery();
            conexion.Close();
        }

        public List<Empleado> filtrarEmpleados(Empleado nuevo)
        {
            List<Empleado> Lista = new List<Empleado>();
            SqlConnection conexion = new SqlConnection();
            SqlCommand comando = new SqlCommand();
            SqlDataReader lector;

            conexion.ConnectionString = "data source = DESKTOP-A3AHOCB; initial catalog=EMPLEADOS_DB; integrated security=sspi";
            comando.CommandType = System.Data.CommandType.Text;
            comando.Parameters.AddWithValue("@NombreCompleto", nuevo.Nombre);
            comando.CommandText = "Select * from Empleados where NombreCompleto = @NombreCompleto ";
            comando.Connection = conexion;
            conexion.Open();

            lector = comando.ExecuteReader();

            while (lector.Read())
            {
                Empleado aux = new Empleado();
                aux.Id = lector.GetInt32(0);
                aux.Nombre = lector.GetString(1);
                aux.Dni = lector.GetString(2);
                aux.Edad = lector.GetInt32(3);
                aux.Casado = lector.GetBoolean(4);
                aux.Salario = lector.GetDecimal(5);

                Lista.Add(aux);
            }

            conexion.Close();

            return Lista;
        }

        public void agregar(Empleado nuevo)
        {
            SqlConnection conexion = new SqlConnection("data source = DESKTOP-A3AHOCB; initial catalog=EMPLEADOS_DB; integrated security=sspi");
            SqlCommand comando = new SqlCommand();

            comando.Connection = conexion;
            comando.CommandType = System.Data.CommandType.Text;
            comando.Parameters.AddWithValue("@NombreCompleto", nuevo.Nombre);
            comando.Parameters.AddWithValue("@DNI", nuevo.Dni);
            comando.Parameters.AddWithValue("@Edad", nuevo.Edad);
            comando.Parameters.AddWithValue("@Casado", nuevo.Casado);
            comando.Parameters.AddWithValue("@Salario", nuevo.Salario);
            comando.CommandText = "insert into Empleados (NombreCompleto, DNI, Edad, Casado, Salario) values (@NombreCompleto , @DNI, @Edad , @Casado , @Salario )";

            conexion.Open();
            comando.ExecuteNonQuery();
            conexion.Close();
        }

        public void eliminar(Empleado nuevo)
        {
            SqlConnection conexion = new SqlConnection("data source = DESKTOP-A3AHOCB; initial catalog=EMPLEADOS_DB; integrated security=sspi");
            SqlCommand comando = new SqlCommand();

            comando.Connection = conexion;
            comando.CommandType = System.Data.CommandType.Text;
            comando.Parameters.AddWithValue("@NombreCompleto", nuevo.Nombre);
            comando.CommandText = "delete from dbo.Empleados Where NombreCompleto = @NombreCompleto";

            conexion.Open();
            comando.ExecuteNonQuery();
            conexion.Close();
        }
    }
}
