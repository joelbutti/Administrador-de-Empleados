﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Administrador_De_Empleados
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            Empleado nuevo = new Empleado();
            EmpleadoConexion conexion = new EmpleadoConexion();
            nuevo.Nombre = tbFiltrar.Text;

            if (tbFiltrar.Text.Equals(null))
            {
                cargar();
            }
            else
            {
                dgvEmpleados.DataSource = conexion.filtrarEmpleados(nuevo);
            }
        }

        private void btnRetirar_Click(object sender, EventArgs e)
        {
            cargar();
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            frmModificar ventana = new frmModificar();
            ventana.ShowDialog();
            cargar();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            frmEliminar ventana = new frmEliminar();
            ventana.ShowDialog();
            cargar();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            frmAgregar ventana = new frmAgregar();
            ventana.ShowDialog();
            cargar();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cargar();
        }

        private void cargar()
        {
            EmpleadoConexion conexion = new EmpleadoConexion();
            dgvEmpleados.DataSource = conexion.listarEmpleados();

        }
    }
}
