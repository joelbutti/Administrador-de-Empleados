﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Administrador_De_Empleados
{
    public partial class frmEliminar : Form
    {
        public frmEliminar()
        {
            InitializeComponent();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            Empleado nuevo = new Empleado();
            EmpleadoConexion conexion = new EmpleadoConexion();
            nuevo.Nombre = tbEliminar.Text;


            conexion.eliminar(nuevo);

            Close();
        }
    }
}
